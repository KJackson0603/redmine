This plug-in is a plug-in that automatically creates a new B work when the status of A work is changed to A'.
You can set several rules by adding conditions in Plug-in settings.

- Install -
1. download the 'zip' file.
2. unzip
3. insert 'zip' file into the /usr/src/redmine/plugins/here.unzip directory.
4. container restart. (if you commit the image instead of restart, you have to run using new image contained this plugin. Then, it'll be working.)

- User Procedure -
1. Administration - Plugins - Check 'Auto Clone On Status Change Dynamic' plugin in the lists.

2. click the 'Configure'

3. Set the rules. 

4. If you need more rules, click the "Add Rules(규칙 추가)" and set
